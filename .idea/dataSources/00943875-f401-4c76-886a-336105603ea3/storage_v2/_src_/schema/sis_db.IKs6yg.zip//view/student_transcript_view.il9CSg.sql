create definer = root@localhost view student_transcript_view as
select `s`.`student_id`     AS `student_id`,
       `s`.`student_number` AS `student_number`,
       `u`.`first_name`     AS `first_name`,
       `u`.`last_name`      AS `last_name`,
       `s`.`admission_year` AS `admission_year`,
       `s`.`major`          AS `major`,
       `s`.`minor`          AS `minor`,
       `cc`.`course_code`   AS `course_code`,
       `cc`.`course_name`   AS `course_name`,
       `t`.`term_name`      AS `term_name`,
       `g`.`grade_code`     AS `grade_code`,
       `e`.`status`         AS `status`
from ((((((`sis_db`.`students` `s` join `sis_db`.`users` `u`
           on ((`u`.`user_id` = `s`.`student_id`))) join `sis_db`.`enrollments` `e`
          on ((`e`.`student_id` = `s`.`student_id`))) join `sis_db`.`course_sections` `cs`
         on ((`cs`.`section_id` = `e`.`section_id`))) join `sis_db`.`course_catalog` `cc`
        on ((`cc`.`catalog_course_id` = `cs`.`catalog_course_id`))) join `sis_db`.`terms` `t`
       on ((`t`.`term_id` = `cs`.`term_id`))) left join `sis_db`.`grades` `g`
      on ((`g`.`enrollment_id` = `e`.`enrollment_id`)))
where (`e`.`status` in ('ENROLLED', 'COMPLETED'));

