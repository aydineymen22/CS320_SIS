create definer = root@localhost view course_listing_view as
select `cs`.`section_id`                                                          AS `section_id`,
       `cc`.`course_code`                                                         AS `course_code`,
       `cc`.`course_name`                                                         AS `course_name`,
       `cs`.`section_no`                                                          AS `section_no`,
       `t`.`term_name`                                                            AS `term_name`,
       `cs`.`quota`                                                               AS `quota`,
       count((case when (`e`.`status` = 'ENROLLED') then 1 end))                  AS `enrolled_count`,
       (`cs`.`quota` - count((case when (`e`.`status` = 'ENROLLED') then 1 end))) AS `available_quota`,
       `u`.`user_id`                                                              AS `instructor_id`,
       concat(`u`.`first_name`, ' ', `u`.`last_name`)                             AS `instructor_name`
from ((((((`sis_db`.`course_sections` `cs` join `sis_db`.`course_catalog` `cc`
           on ((`cc`.`catalog_course_id` = `cs`.`catalog_course_id`))) join `sis_db`.`terms` `t`
          on ((`t`.`term_id` = `cs`.`term_id`))) left join `sis_db`.`section_instructors` `si`
         on ((`si`.`section_id` = `cs`.`section_id`))) left join `sis_db`.`instructors` `i`
        on ((`i`.`instructor_id` = `si`.`instructor_id`))) left join `sis_db`.`users` `u`
       on ((`u`.`user_id` = `i`.`instructor_id`))) left join `sis_db`.`enrollments` `e`
      on ((`e`.`section_id` = `cs`.`section_id`)))
group by `cs`.`section_id`, `cc`.`course_code`, `cc`.`course_name`, `cs`.`section_no`, `t`.`term_name`, `cs`.`quota`,
         `u`.`user_id`, `u`.`first_name`, `u`.`last_name`;

